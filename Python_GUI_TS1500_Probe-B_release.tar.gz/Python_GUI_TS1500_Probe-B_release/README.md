# Python GUI TS1500 Probe-B Quick Setup

This release contains a setup script that will automatically install and run the Python GUI TS1500 Probe-B application using Docker.

## Requirements
- Arch Linux or compatible Linux distribution
- Internet connection
- USB port for Arduino connection

## Installation

1. Extract the release package:
